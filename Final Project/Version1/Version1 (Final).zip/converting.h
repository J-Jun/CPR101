
#ifndef _CONVERTING_H
#define _CONVERTING_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define TRUE 1

//--------------------------------
// Function Prototypes
//--------------------------------

// converting: 
void converting();

#endif



