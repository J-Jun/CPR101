
#ifndef _TOKENIZING_H
#define _TOKENIZING_H

#include <stdio.h>
#include <string.h>

#define TRUE 1

//--------------------------------
// Function Prototypes
//--------------------------------

// tokenizing:
void tokenizing();

#endif

