
#ifndef _MANIPULATING_H
#define _MANIPULATING_H

#include <stdio.h>
#include <string.h>

#define TRUE 1

//--------------------------------
// Function Prototypes
//--------------------------------

// manipulating:
void manipulating();

#endif